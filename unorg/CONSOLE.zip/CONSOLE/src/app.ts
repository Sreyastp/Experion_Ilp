
const form = document.querySelector('#new-item-form') as HTMLFormElement;
console.log(form.children);

// inputs
const a = document.querySelector('#validationDefault01') as HTMLInputElement;
const b = document.querySelector('#validationDefault02') as HTMLInputElement;
const c = document.querySelector('#validationDefault03') as HTMLInputElement;
const d = document.querySelector('#validationDefault04') as HTMLInputElement;
const e = document.querySelector('#validationDefault14') as HTMLInputElement;
const f = document.querySelector('#validationDefault05') as HTMLInputElement;
const g = document.querySelector('#validationDefault06') as HTMLInputElement;
const h = document.querySelector('#validationDefault07') as HTMLInputElement;
const i = document.querySelector('#validationDefault08') as HTMLInputElement;
const j = document.querySelector('#validationDefault09') as HTMLInputElement;
const k = document.querySelector('#validationDefault10') as HTMLInputElement;
const l = document.querySelector('#validationDefault11') as HTMLInputElement;
const m = document.querySelector('#validationDefault12') as HTMLInputElement;
const n = document.querySelector('#validationDefault13') as HTMLInputElement;
const o = document.querySelector('#invalidCheck2') as HTMLInputElement;

form.addEventListener('submit', (e: Event) => {
  e.preventDefault();

  console.log(
    a.value, 
    b.value, 
    c.value, 
    d.value,
    //e.value,
    f.value,
    g.value,
    h.value,
    i.value,
    j.value,
    k.value,
    l.value,
    m.value,
    n.value,
    o.value
    
  );
  console.log(b.value);
});