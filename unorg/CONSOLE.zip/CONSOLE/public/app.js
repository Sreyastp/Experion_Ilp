"use strict";
const form = document.querySelector('#new-item-form');
console.log(form.children);
// inputs
const a = document.querySelector('#validationDefault01');
const b = document.querySelector('#validationDefault02');
const c = document.querySelector('#validationDefault03');
const d = document.querySelector('#validationDefault04');
const e = document.querySelector('#validationDefault14');
const f = document.querySelector('#validationDefault05');
const g = document.querySelector('#validationDefault06');
const h = document.querySelector('#validationDefault07');
const i = document.querySelector('#validationDefault08');
const j = document.querySelector('#validationDefault09');
const k = document.querySelector('#validationDefault10');
const l = document.querySelector('#validationDefault11');
const m = document.querySelector('#validationDefault12');
const n = document.querySelector('#validationDefault13');
const o = document.querySelector('#invalidCheck2');
form.addEventListener('submit', (e) => {
    e.preventDefault();
    console.log(a.value, b.value, c.value, d.value, 
    //e.value,
    f.value, g.value, h.value, i.value, j.value, k.value, l.value, m.value, n.value, o.value);
    console.log(b.value);
});
