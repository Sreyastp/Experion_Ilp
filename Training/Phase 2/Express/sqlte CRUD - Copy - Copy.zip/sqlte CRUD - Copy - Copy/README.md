# codegig
Demo Project to show how to create CRUD operations using 
Node.js
Express
Sequelize
PostgreSQL