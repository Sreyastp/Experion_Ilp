// import Header from "./Components/Header/Header";

import Routers from "./Components/Routes/Routes";
import './App.css';
function App() {
  return (
    <>
    <Routers />
    </>
  );
}

export default App;
