import './Home.css'


function Home(){

    return(
        <div className="homeBox">
            <div className="contentBox contentBoxA"></div>
            <div className="contentBox contentBoxB"></div>
            <div className="contentBox contentBoxC"></div>
        
        </div>

    )
}


export default Home;