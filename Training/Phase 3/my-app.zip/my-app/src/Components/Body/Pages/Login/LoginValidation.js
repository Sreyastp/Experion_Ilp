import axios from "axios";


function LoginValidation(email, password){

        //axios.get - userdb/email
        //if not exist log-"not found"
        //if exist verify passoword == user-input-password
        //If true navigate to customer enquiry form

}