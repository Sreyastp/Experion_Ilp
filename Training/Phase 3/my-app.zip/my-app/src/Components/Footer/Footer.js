import './Footer.css';

function Footer(){


    return(
        <footer className="footer">
            Footer Content here
        </footer>
    )
}

export default Footer;